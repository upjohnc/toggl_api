from distutils.core import setup

setup(
    name='TogglApi',
    version='0.2',
    packages=['toggl_api', ],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)
