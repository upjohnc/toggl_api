from distutils.core import setup

setup(
    name='TogglApi',
    version='0.1dev',
    packages=['toggl_api', ],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.md').read(),
)
